Toxic Underground - Gabber Edition v1
Modified interface PNGs: 617
Original filenames and directories preserved.
Muted moss-green industrial palette. Spell and prayer icons preserved.
